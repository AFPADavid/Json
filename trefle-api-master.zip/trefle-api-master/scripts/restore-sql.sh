pg_restore --data-only -d trefle_dev -U remo -p5432 -hlocalhost data.dump
