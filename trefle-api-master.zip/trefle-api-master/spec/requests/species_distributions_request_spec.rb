require 'rails_helper'

RSpec.describe 'SpeciesDistributions', type: :request do

end
