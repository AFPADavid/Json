require 'rails_helper'

RSpec.describe 'CommonNames', type: :request do

end
