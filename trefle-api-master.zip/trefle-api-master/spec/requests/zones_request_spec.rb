require 'rails_helper'

RSpec.describe 'Zones', type: :request do

end
