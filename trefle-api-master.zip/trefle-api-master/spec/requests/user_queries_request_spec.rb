require 'rails_helper'

RSpec.describe 'UserQueries', type: :request do

end
