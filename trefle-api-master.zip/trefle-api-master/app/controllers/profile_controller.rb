class ProfileController < ApplicationController

  before_action :check_user

  def index; end
end
